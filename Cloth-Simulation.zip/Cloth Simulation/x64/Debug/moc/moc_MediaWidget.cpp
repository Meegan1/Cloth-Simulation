/****************************************************************************
** Meta object code from reading C++ file 'MediaWidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../MediaWidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MediaWidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MediaWidget_t {
    QByteArrayData data[27];
    char stringdata0[326];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MediaWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MediaWidget_t qt_meta_stringdata_MediaWidget = {
    {
QT_MOC_LITERAL(0, 0, 11), // "MediaWidget"
QT_MOC_LITERAL(1, 12, 11), // "playPressed"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 13), // "recordPressed"
QT_MOC_LITERAL(4, 39, 11), // "savePressed"
QT_MOC_LITERAL(5, 51, 16), // "updatePlayButton"
QT_MOC_LITERAL(6, 68, 9), // "isPlaying"
QT_MOC_LITERAL(7, 78, 18), // "updateRecordButton"
QT_MOC_LITERAL(8, 97, 11), // "isRecording"
QT_MOC_LITERAL(9, 109, 11), // "loadPressed"
QT_MOC_LITERAL(10, 121, 12), // "facesPressed"
QT_MOC_LITERAL(11, 134, 14), // "springsPressed"
QT_MOC_LITERAL(12, 149, 13), // "pointsPressed"
QT_MOC_LITERAL(13, 163, 11), // "toggleFaces"
QT_MOC_LITERAL(14, 175, 9), // "showFaces"
QT_MOC_LITERAL(15, 185, 13), // "toggleSprings"
QT_MOC_LITERAL(16, 199, 11), // "showSprings"
QT_MOC_LITERAL(17, 211, 12), // "togglePoints"
QT_MOC_LITERAL(18, 224, 10), // "showPoints"
QT_MOC_LITERAL(19, 235, 15), // "scenarioPressed"
QT_MOC_LITERAL(20, 251, 11), // "setScenario"
QT_MOC_LITERAL(21, 263, 8), // "scenario"
QT_MOC_LITERAL(22, 272, 12), // "frameRateSet"
QT_MOC_LITERAL(23, 285, 10), // "frame_rate"
QT_MOC_LITERAL(24, 296, 11), // "windPressed"
QT_MOC_LITERAL(25, 308, 11), // "windToggled"
QT_MOC_LITERAL(26, 320, 5) // "value"

    },
    "MediaWidget\0playPressed\0\0recordPressed\0"
    "savePressed\0updatePlayButton\0isPlaying\0"
    "updateRecordButton\0isRecording\0"
    "loadPressed\0facesPressed\0springsPressed\0"
    "pointsPressed\0toggleFaces\0showFaces\0"
    "toggleSprings\0showSprings\0togglePoints\0"
    "showPoints\0scenarioPressed\0setScenario\0"
    "scenario\0frameRateSet\0frame_rate\0"
    "windPressed\0windToggled\0value"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MediaWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   99,    2, 0x08 /* Private */,
       3,    0,  100,    2, 0x08 /* Private */,
       4,    0,  101,    2, 0x08 /* Private */,
       5,    1,  102,    2, 0x08 /* Private */,
       7,    1,  105,    2, 0x08 /* Private */,
       9,    0,  108,    2, 0x08 /* Private */,
      10,    0,  109,    2, 0x08 /* Private */,
      11,    0,  110,    2, 0x08 /* Private */,
      12,    0,  111,    2, 0x08 /* Private */,
      13,    1,  112,    2, 0x08 /* Private */,
      15,    1,  115,    2, 0x08 /* Private */,
      17,    1,  118,    2, 0x08 /* Private */,
      19,    0,  121,    2, 0x08 /* Private */,
      20,    1,  122,    2, 0x08 /* Private */,
      22,    1,  125,    2, 0x08 /* Private */,
      24,    0,  128,    2, 0x08 /* Private */,
      25,    1,  129,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    6,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   14,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   18,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   26,

       0        // eod
};

void MediaWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MediaWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->playPressed(); break;
        case 1: _t->recordPressed(); break;
        case 2: _t->savePressed(); break;
        case 3: _t->updatePlayButton((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->updateRecordButton((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->loadPressed(); break;
        case 6: _t->facesPressed(); break;
        case 7: _t->springsPressed(); break;
        case 8: _t->pointsPressed(); break;
        case 9: _t->toggleFaces((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->toggleSprings((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: _t->togglePoints((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 12: _t->scenarioPressed(); break;
        case 13: _t->setScenario((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->frameRateSet((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->windPressed(); break;
        case 16: _t->windToggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MediaWidget::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_MediaWidget.data,
    qt_meta_data_MediaWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MediaWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MediaWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MediaWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int MediaWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 17;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
