This project uses the NuGet package manager in visual studio to include opengl and glm, ensure that these are imported!


Usage:
    Run the project, GUI controls are given to change scenario, pause & play, record etc.


Recording:
    Recording can be done by clicking record, the frames are then outputted into the video folder, along with the ffmpeg command needed to 
    render the frames into a video.